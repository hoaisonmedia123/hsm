// Game
let altTabbed = false;
let toggleChat = false;
let disableChat = false;
