'use strict';

exports.create = () => {
  return {
    id: null,
    name: null,
    groupId: null
  };
};
