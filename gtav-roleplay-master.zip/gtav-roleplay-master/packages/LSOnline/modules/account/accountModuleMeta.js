'use strict';

exports.IPB_MEMBERS_TABLE = 'core_members';
exports.HASH_SELECT_QUERY_PATTERN = "SELECT %s FROM %s WHERE name LIKE '%s' LIMIT 1";
exports.MODULE_NAME = 'Account';
